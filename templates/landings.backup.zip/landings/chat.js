document.querySelector('.send-btn').addEventListener('click', function() {
  const input = document.querySelector('.message-input');
  const messageText = input.value.trim();

  if (messageText) {
    const messageDiv = document.createElement('div');
    messageDiv.classList.add('message', 'sent');
    messageDiv.innerHTML = `
      <div class="message-content">
        <p>${messageText}</p>
        <span class="timestamp">${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
      </div>
    `;
    document.querySelector('.chat-messages').appendChild(messageDiv);
    input.value = '';
    messageDiv.scrollIntoView({ behavior: 'smooth' });
  }
});

document.querySelector('.message-input').addEventListener('keypress', function(e) {
  if (e.key === 'Enter') {
    document.querySelector('.send-btn').click();
  }
});